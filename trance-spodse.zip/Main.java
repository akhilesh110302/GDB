import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner sc=new Scanner(System.in);
	    System.out.print("Enter the row Number ");
	    int r=sc.nextInt(); 
	    System.out.print("Enter the column Number ");
	    int c=sc.nextInt();
	    int a[][]=new int[r][c];
	    int b[][]=new int[r][c];
	    System.out.print("Enter the Element of First Matrix ");
	    for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	            a[i][j]=sc.nextInt();
	        }
	    }
        for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	           	System.out.print( a[i][j]+" ");
	        }	
	        System.out.println();
	    }
	    for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	            b[i][j]=a[j][i];
	          
	        }	
	        System.out.println();
	    }
	    for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	           	System.out.print( b[i][j]+" ");
	        }	
	        System.out.println();
	    }
	}
	 
	    
	
}