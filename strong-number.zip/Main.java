import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    int sum=0;
	    Scanner sc= new Scanner(System.in);
	    int n=sc.nextInt();
	    int num=0;
	    int ki=n;
	    
	    while(n>0)
	    {
	        num=n%10;
	       int  k=is(num);
	        sum=k+sum;
	        n=n/10;
	    }
	    if(sum==ki)
	    {
	       System.out.println("strong "+sum+" "+ ki); 
	    }
	    else
	    {
	        System.out.println(" not strong "+sum+" "+ ki); 
	    }
	    
	}
	static int is(int n)
	{
	    int j=1;
	    for(int l=n;l>0;l--)
	    {
	        j=l*j;
	    }
	    return j;
	}
}
