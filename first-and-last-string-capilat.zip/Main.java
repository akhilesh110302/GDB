import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner sc=new Scanner(System.in);
	    String str=sc.nextLine();
	    String[] string=str.split("\\s");

	    for(String s:string)
	    {	    
	        int n=s.length();
            String first=s.substring(0, 1).toUpperCase();    
    	    
    	    String secound=s.substring(1, n-1);    
    
            char sss=s.charAt(n-1);
            char last= Character.toUpperCase(sss);
            
	        System.out.print(first+secound+last+" ");
	    }
		
	}
}
