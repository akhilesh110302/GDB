import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
          String str=sc.next();	  
            String s=sc.next();	  
	    if(s.equals(str))
	    {
	       	System.out.println("it is a pallindrom");
	    }
	
	}
}
