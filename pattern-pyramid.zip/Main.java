import java.util.*;

public class Main
{
	public static void main(String[] args)
	{
        Scanner sc=new Scanner (System.in);
        int n=9;

        for(int i=0;i<n;i++)
        {
            for(int j=n;j>i;j--)
            {
                System.out.print(" ");
            }
            for(int k=0;k<=i;k++)
            {
                System.out.print("*");
            }
           
           
                for(int p=0;p<i;p++)
                {
                    System.out.print("*");
                }   
           System.out.println();
        }
       
	}
}
