import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc =new Scanner(System.in);
		String c=sc.next();
	        String s1="";
	        for(int i=0;i<c.length();i++)
	    {
	        char s=c.charAt(i);    
	
	        
	        s1 = c.replaceAll("[aeiou]", "*"); 
	
	   }
		    
		       System.out.println(s1) ;
	}
}

