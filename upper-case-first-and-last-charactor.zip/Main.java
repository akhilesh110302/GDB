import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s="";
		String str=sc.nextLine();
		String[] a=str.split("\\s");
		String firstchar=Character.str.charAt()
        for()
        {
            for(int i=0;i<a.length;i++)
            {
                
            }
        }
        System.out.println(" "+s);
	}
}
