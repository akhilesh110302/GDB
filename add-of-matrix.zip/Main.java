import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner sc=new Scanner(System.in);
	    System.out.print("Enter the row Number ");
	    int r=sc.nextInt(); 
	    System.out.print("Enter the column Number ");
	    int c=sc.nextInt();
	    int a[][]=new int[r][c];int b[][]=new int[r][c];int d[][]=new int[r][c];
	    System.out.print("Enter the Element of First Matrix ");
	    a=take(a,r,c);
	    print(a,r,c);
	  
        System.out.print("Enter the Element of secound Matrix ");
        b=take(b,r,c);
	    print(b,r,c);
	    
	    
	    for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	           d[i][j]=a[i][j]+b[i][j];
	        }	
	        System.out.println();
	    }
	    print(d,r,c);
	    
	
	}
	public static int[][] take( int a[][] ,int r,int c)
	{ 
	    Scanner sc=new Scanner(System.in);
	    for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	            a[i][j]=sc.nextInt();
	        }
	    }
	    return a;
	}
	public static void print( int a[][] ,int r,int c)
	{ 
	    for(int i=0;i<r;i++)
	    {
	        for(int j=0;j<c;j++)
	        {
	           	System.out.print( a[i][j]+" ");
	        }	
	        System.out.println();
	    }
	}

}
