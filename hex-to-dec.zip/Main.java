import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    String n=sc.nextLine();
	   // int l=findlenegth(n); 
	    int sum=0;int k=n.length()-1,num;
	    n=n.toUpperCase();
	    String temp="0123456789ABCDEF";
	    for (int i=0;i<n.length();i++ ) 
	    {
	        char a=n.charAt(i);
	        int t= temp.indexOf(a);
	        System.out.println("t : "+t);
	        if(t==0)
	        {
	            sum=sum+0; 
	            k--; 	
	        }
	        if(t>0)
	        {
	            sum=sum+t*(int)Math.pow(16,k);
	            System.out.println(sum+"   : "+k);
	            k--;
	        }   
	       
	    }
	
	  
	}

}

