import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc =new Scanner(System.in);
		String c=sc.next();
		String s="";
		for(int i=0;i<c.length();i++)
		{
		    if(Character.isUpperCase(c.charAt(i)))
		    {
		        s=s+Character.toLowerCase(c.charAt(i));
		    }
		    else
		    {
		        s=s+Character.toUpperCase(c.charAt(i));
		    }
		}
		System.out.println(" "+s);
	}
}
