import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int k=n;
	    int l=findlenegth(n); 
	    int sum=0;
	    for (int i=1;i<=l ;i++ ) 
	    {
	        int num =n%10;
	        n=n/10;
	        sum=sum+num;
	    }
	    if(k%sum==0)
	    {
	       System.out.println("Harashad number : "+(k/sum)); 
	    }
	    else
	    {
	      System.out.println("Not Harashad number : "+(k/sum));  
	    }
		
	}
	static int findlenegth(int n)
	{
	    int count=0;
	    while(n>0)
	    {
	        n=n/10;
	        count++;
	    }
	    
	    return count;
	}
}

