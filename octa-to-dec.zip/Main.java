import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int l=findlenegth(n); 
	    int sum=0;int k=0,num;
	    for (int i=1;i<=l ;i++ ) 
	    {
	         num=n%10;
	            n=n/10;
	        if(num==0)
	        {
	            sum=sum+0; 
	            k++; 	
	        }
	        if(num>0)
	        {
	            sum=sum+num*(int)Math.pow(8,k);
	            k++;
	        }
	    }
	    System.out.println(sum);
	  
	}
	static int findlenegth(int n)
	{
	    int count=0;
	    while(n>0)
	    {
	        n=n/10;
	        count++;
	    }
	    
	    return count;
	}
}

