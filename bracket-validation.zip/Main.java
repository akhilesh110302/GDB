import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    String s=sc.next();  
        ArrayList<Character> a=new ArrayList<Character>();
	    for(int i=0;i<s.length();i++)
	    {
	        if(s.charAt(0)=='}' || s.charAt(0)==')' || s.charAt(0)==']'  )
	        {
	            char ch=s.charAt(i);
    	        a.add(ch);
	            break;
	        }
	        else
	        {
    	        if(s.charAt(i)=='{' || s.charAt(i)=='(' || s.charAt(i)=='[')
    	        {
    	            char ch=s.charAt(i);
    	            a.add(ch);
    	        }
    	        else if( a.isEmpty() || s.charAt(i)=='}' || s.charAt(i)==')' || s.charAt(i)==']')
    	        {
    	            char ch=s.charAt(i);
    	            a.add(ch);
    	            break;
    	        }
    	        else 
    	        {
    	            int in = a.size() - 1;
    	            if(a.get(in)=='{' )
    	            {
        	             char ch=s.charAt(i);
        	             a.remove(in);
    	            }
    	            else if(a.get(in)=='(')
    	            {
    	                char ch=s.charAt(i);
    	                a.remove(in);
    	            }
    	            else
    	            {
    	                 char ch=s.charAt(i);
    	                 a.remove(in);
    	            }
    	        }
	        }
	    }
	    if(a.isEmpty())
	    {
	        System.out.println("String is Valid");
	    }
	    else{
	        System.out.println("String is Not Valid");
	    }
		
	}
}
