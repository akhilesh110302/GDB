import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		String s2=sc.next();
		boolean a=false;
		s1.toLowerCase();s2.toLowerCase();
		if(s1.length()==s2.length())
		{
		     a=ana(s1,s2);
		}
		if(a)
		{
		    System.out.println(s1+" and "+s2 +" is Anagram");
		}
		else
		{
		    System.out.println(s1+" and "+s2 +" is Not Anagram");
		}
	}
	static boolean ana(String s1,String s2)
	{
	    s1.replaceAll("[\\s]","");
	    char a[]=s1.toCharArray();
	     s2.replaceAll("[\\s]","");
	     char b[]=s2.toCharArray();
	    Arrays.sort(a);
	    Arrays.sort(b);
	    for(int i=0;i<a.length;i++)
	    {
	        
	    System.out.println(a[i]+" " +b[i]);
	    }
	    if(Arrays.equals(a,b))
	    {
	        return true;
	    }
	    return false;
	}
}
