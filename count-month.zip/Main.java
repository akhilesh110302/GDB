import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();	    int y=sc.nextInt();
	   
	     if((n==2) && ((y%4==0) || ((y%100==0)&&(y%400==0))))
         {
             System.out.println("Number of days is 29");
}
        else if(n==2)
        {
            System.out.println("Number of days is 28");
        }
	    else if(n==4||n==6||n==9||n==11)
	    {
    		System.out.println("30");	        
	    }
        else
        {
            System.out.println("31");   
        }
	}
}
