import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the Number");
	    int n=sc.nextInt();
	    if(n==0)
	    {
	        System.out.println("Number is zero");
	    }
		else
		{ 
		    String str= n>0 ? n+" is Positiive Number ": n+ " Negative Number";
		    System.out.println( str);
		    
		}
		
	}
}
