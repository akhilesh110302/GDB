import java.util.*;
public class Main
{
	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int k=n*n;
	    int f=k%10;
	    if(f==n)
	    {
	       System.out.println("ok"+f); 
	    }
	    else
	    {
	      System.out.println("Hello World "+f);  
	    }
		
	}
}
