import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner sc=new Scanner(System.in);
	    String s=sc.nextLine();
	    
	    int a[]=new int[s.length()];
	    for(int i=0;i<s.length();i++)
	    {
	        a[i]=1;int c=1;
	        for(int j=0;j<s.length();j++)
	        {  
	            char x=s.charAt(i);
	           // String z= Character.toString(x);
                int z=x;
                char y=s.charAt(j);
	          //  String o= Character.toString(y);
	            int o=y;
	             // System.out.println(z+" "+o);
	              if(z==o)
	            {
	                c++;
	                
	                a[i]=c;
	                
	            }
	            
	        }
	        
	        
	    }
	  
	    for(int i=0;i<s.length();i++)
	    {
	        
	        int k=Arrays.stream(a).max().getAsInt();
	        System.out.println(s.charAt(k)+" "+a[i]);
	        
	    }
		
	}
}
