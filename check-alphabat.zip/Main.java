import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char c=sc.next().charAt(0);
		if((c>65 && c<90) ||(c<122 &&c>97))
		{
		System.out.println("it is alphabat "+ c);	    
		}
		else
		{
		    System.out.println(" not alphabat  "+ c);	    
		}
	
	}
}
