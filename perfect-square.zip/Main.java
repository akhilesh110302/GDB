import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n=sc.nextInt();
	    int sum=0;
        double z=Math.floor(Math.sqrt(n));
        double y=Math.ceil(Math.sqrt(n));
   
        if(z==y)
        {
            System.out.println("yes"+z+" "+y+" " );
        }
	}
}


